<?php $__env->startSection('content'); ?>
	<div class="right_col" role="main">
		  <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  

  <div class="col-xs-12 col-md-4 col-lg-3">
    <div class="panel-default panel">
      <div class="panel-heading">
          <strong>Employee Profile</strong>
      </div>

      <div class="panel-body">
          <?php $url= url('storage/app/avatars/');?>
          <?php if(!empty($user->image)):?>
          <div class="form-group">
            <img src="<?php echo e($url.'/'.$user->image); ?>" class="img-thumbnail" >
          </div>
          <?php else:?>
          <div class="form-group">
            <img src="<?php echo e($url.'/avatar.png'); ?>" class="img-thumbnail">
          </div>        
          <?php endif?>
          <div class="">
            <strong><p>Name: <?php echo e($user->name); ?></p></strong>
            <strong><p>Email: <?php echo e($user->email); ?></p></strong>
            <strong><p>About: <?php echo e($user->about); ?></p></strong>
          </div>     
      </div>

    </div>
  </div>

	</div><!--main  col div end-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>