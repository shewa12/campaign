<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">

		<div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        
      	</div>     
      	<!--end flass message-->
      	<div class="clearfix"></div>
      	<!--body-->
      	<div class="row">
      		<div class="panel-default panel">
      			<div class="panel-heading">
      				Campaign Dashbaord
      			</div>

      			<div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover" id="example">
                    <thead>
                    <tr>
                        <th>Sl No: <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Campaign Title <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>A SIN <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Product Link <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Full Price <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>View Detail <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        
                    </tr>
                    </thead>
                    <tbody>
                      <?php 
                        $i=1;
                      ?>

                    <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($value->title); ?></td>
                        <td><?php echo e($value->asin); ?></td>
                        <td><?php echo e($value->product_link); ?></td>
                        <td><?php echo e($value->full_price); ?></td>
                        <td><a href="<?php echo e(url('asigned-campaign/detail')); ?>/<?php echo e($value->id); ?>" class="btn-primary btn btn-sm">View Detail</a></td>
                        
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>No record found</td>
                      </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                

              </div>
      			</div>
      		</div>
      	</div>
      	<!--body end-->
  	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>