<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">

		<div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        
      	</div>     
      	<!--end flass message-->
      	<div class="clearfix"></div>
      	<!--body-->
      	<div class="row">
      		<div class="panel-default panel">
      			<div class="panel-heading">
      				<strong> Campaign Detail</strong>
      			</div>

      			<div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Sl No:</th>
                        <th>A SIN</th>
                        <th>Product Link</th>
                        <th>Full Price</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                      <?php 
                        $i=1;
                      ?>

                    <?php $__empty_1 = true; $__currentLoopData = $campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                      <?php $fullprice= $value->full_price;?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($value->asin); ?></td>
                        <td><?php echo e($value->product_link); ?></td>
                        <td><?php echo e($value->full_price); ?></td>
                        
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>No record found</td>
                      </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <div class="clearfix"></div>
                <!--keyword detail-->
                <?php $grandTotal=[];?>
                <?php $__empty_1 = true; $__currentLoopData = $keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <div class="col-xs-12 col-md-8 col-lg-6">
                  <table class="table-bordered table">
                      
                        <tbody>

                          <tr>
                            <td>Keyword</td>
                            <td width="30%"><?php echo e($val->keyword); ?></td>
                          </tr>                        
                          <tr>
                            <td>Sale per Day</td>
                            <td width="30%"><?php echo e($val->perday_sale); ?></td>
                          </tr>                        
                          <tr>
                            <td>Product on Page</td>
                            <td width="30%"><?php echo e($val->product_page); ?></td>
                          </tr>                          
                          <tr>
                            <td>Duration</td>
                            <td width="30%"><?php echo e($val->duration); ?></td>
                          </tr>
                          <tr>
                            <td colspan="2" style="text-align:right;font-weight:bold"><span>Per day sale*duration*per sale cost(15) = 
                            <?php
                              echo $totalOne= $val->perday_sale*$val->duration*15;
                              
                            ?>
                            </span><br>
                            <span>perday sale * duration * full price= 
                            <?php 
                              echo $totalTwo= $val->perday_sale*$val->duration*$fullprice;
                              
                            ?></span><br>
                            <span class="total">Total: $<?php echo e($grandTotal[]= $totalOne+$totalTwo); ?></span>
                            </td>
                          </tr>

                        </tbody>
                     
                  </table>


                </div>
                <div class="clearfix"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                  <span><strong>No keyword found</strong></span>
                <?php endif; ?>
                  <div class="col-xs-12 col-md-8 col-lg-6 grand-total">
                    <?php 
                      $amount=0;
                      for($i=0;$i<count($grandTotal);$i++){
                        $k= $i+1;
                        echo "Keyword ".$k." total= $".number_format((float)$grandTotal[$i],'2','.','')."<br>";
                          $amount= $amount+$grandTotal[$i];
                      }
                      
                    ?>
                    <h3>
                      <?php 
                        echo 'Grand Total= $'.number_format((float)$amount,'2','.','');
                      ?>
                    </h3>
                  </div>
                <!--keyword detail end-->
              </div>
      			</div>
      		</div>
      	</div>
      	<!--body end-->
  	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>