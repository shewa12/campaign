<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">

    <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        
        </div>     
        <!--end flass message-->
        <div class="clearfix"></div>
        <!--body-->
        <div class="row">
          <div class="panel-default panel">
            <div class="panel-heading">
              <button class="btn btn-primary addSale" id="<?php echo e($keyword->id); ?>" data-target="#addSale" data-toggle="modal">Add Sale</button>
            </div>

            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Keyword</th>
                        <th>Sale Needed</th>
                        <th>Product on Page</th>
                        <th>Duration</th>
                        <th>Sales Completed</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>

                      <tr>
                        <td><?php echo e($keyword->keyword); ?></td>
                        <td><?php echo e($keyword->perday_sale); ?></td>
                        <td><?php echo e($keyword->product_page); ?></td>
                        <td><?php echo e($keyword->duration); ?> Day</td>
                        <td><?php echo e($saleCount); ?></td>
                        <td>
                          <?php if($keyword->perday_sale*$keyword->duration==$saleCount): ?>
                            <button class="btn btn-sm btn-success">Completed</button>
                          <?php else: ?>
                             <button class="btn btn-sm btn-warning">Inprogress</button>
                          <?php endif; ?>   
                        </td>

                      </tr>

                    </tbody>
                </table>
                
              </div>
            </div>
          </div>
          <!--progress detail-->
          <div class="panel-default panel">
            <div class="panel-heading">
              <strong>Sales completed for above keyword</strong>
            </div>

            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Sl No:</th>
                        
                        <th>Date</th>
                        <th>Timestamps</th>
                        <th>Order No</th>
                        <th>Person name</th>
                        <th>Email</th>
                        <th>Paypal Info</th>
                        <th>Note</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=1;?>  
                    <?php $__empty_1 = true; $__currentLoopData = $progress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>  
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($p->date); ?></td>
                        <td><?php echo e($p->sale_datetime); ?></td>
                        <td>#<?php echo e($p->order_no); ?></td>
                        <td><?php echo e($p->person_name); ?></td>
                        <td><?php echo e($p->email); ?></td>
                        <td><?php echo e($p->paypal); ?></td>
                        <td><?php echo e($p->note); ?></td>


                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <tr><td>No sale added</td></tr>  
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($progress->links()); ?>

              </div>
            </div>
          </div>          
          <!--progress detail end-->
        </div>
        <!--body end-->
<div id="addSale" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Asign employee to campaign</h4>
      </div>
        <div class="modal-body">
          <form class="form-horizontal modal-form" id="loginForm" method="post" action="<?php echo e(route('addSale')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="keyword_id" value="">

            <div class="form-group">
              <label>Date</label>
              <input type="date" class="form-control" name="date"> 
            </div>            
                      
            <div class="form-group">
              <label>Timestamp</label>
              <input type="text" id="timepicker" name="sale_datetime" class="form-control " value=""> 
            </div>            
          
          
            <div class="form-group">
                <label>Person Name</label>
                <input class="form-control" name="person_name" required>
            </div>            
            <div class="form-group">
                <label>Email</label>
                <input class="form-control" name="email" required>
            </div>               

            <div class="form-group">
                <label>Paypal Info</label>
                <input class="form-control" name="paypal" required>
            </div>            
            <div class="form-group">
                <label>Note</label>
                <textarea class="form-control" name="note"></textarea>
            </div>            

            <div class="form-group">
                  <button type="submit" class="btn btn-primary">Add Sale</button>
            </div>
               
        </form>
      </div>

    </div>

  </div>
</div>
    </div><!--right col end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">

  $(document.body).on('click','.addSale',function(){
      
      var id= $(this).attr('id');
      $("[name='keyword_id']").val(id);
  })
  $('#timepicker').timepicki(); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>