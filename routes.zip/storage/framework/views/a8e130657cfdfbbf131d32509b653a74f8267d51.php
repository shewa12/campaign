<?php $__env->startSection('content'); ?>
  <div class="right_col" role="main">
      <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        <!--end flass message-->
      </div>  


    <div class="panel-default panel">
      <div class="panel-heading">
          <strong>Bank Detail</strong>
      </div>

      <div class="panel-body">
        <form class="form" action="<?php echo e(route('updateBank')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <input type="hidden" name="type" value="faq">
            <div class="form-group">
              <label>Update</label>
              <textarea name="content" id="summernote" class="form-control"><?php if(!empty($post)): ?><?php echo $post->content; ?><?php endif; ?></textarea>
            </div> 
            <div class="form-group">
              <button class="btn-primary btn">Update Bank</button>
            </div> 
        </form>
      </div>

    </div>


  </div><!--main  col div end-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
$(document).ready(function() {
  $('#summernote').summernote();
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>