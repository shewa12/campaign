<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Campaign extends Model
{
    //table name
    public $table= "campaign";
    protected $guarded= [];
}
