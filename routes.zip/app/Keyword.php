<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Keyword extends Model
{
    //table name
    public $table= "keyword";
    protected $guarded= [];
}
