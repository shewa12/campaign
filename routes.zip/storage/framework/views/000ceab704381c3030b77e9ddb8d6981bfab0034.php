<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">

    <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        
        </div>     
        <!--end flass message-->
        <div class="clearfix"></div>
        <!--body-->
        <div class="row">
          <div class="panel-default panel">
            <div class="panel-heading">
              <strong>All campaigns</strong>
            </div>

            <div class="panel-body">
              <div class="table-responsive" >
                <table class="table table-bordered table-hover"id="example">
                    <thead>
                    <tr>
                        <th>Sl No: <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Created At <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Capaign Title <i class="fas fa-arrows-alt-v pull-right"></i></th>                        
                        <th>A SIN <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <!--
                        <th>Product Link</th>
                        <th>Full Price</th>
                      -->
                        <th>View Detail <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Asign Employee <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Payment Status <i class="fas fa-arrows-alt-v pull-right"></i></th>
                        <th>Overall Progress</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php 
                        //$i=($campaigns->currentpage()-1)* $campaigns->perpage() + 1;
                        $i=1;
                      ?>

                    <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($value->created_at); ?></td>
                        <td><?php echo e($value->title); ?></td>
                        <td><?php echo e($value->asin); ?></td>
                        <!--
                        <td><?php echo e($value->product_link); ?></td>
                        <td><?php echo e($value->full_price); ?></td>
                      -->
                        <td><a href="<?php echo e(url('/home/campaign-detail/')); ?>/<?php echo e($value->id); ?>" class="btn-primary btn btn-sm">View Detail</a></td>
                        <td>
                          <?php if($value->employee_id==0): ?>
                          <button data-toggle="modal"data-target="#asign" id="<?php echo e($value->id); ?>" class="asign btn-sm btn btn-info">Asign</button>
                          <?php else: ?>
                          <a href="<?php echo e(url('/employee-detail')); ?>/<?php echo e($value->userId); ?>" class="text-capitalize"><strong><?php echo e($value->name); ?></strong></a>
                          <?php endif; ?>
                        </td>
                        <td>
                          <?php if($value->payment_status==0): ?>
                            <button class="btn-default btn btn-sm pending" style="color:#f11c4c" id="<?php echo e($value->id); ?>"> Pending</button>
                          <?php else: ?>
                            <i style="color:green;font-size:20px;" class="fas fa-check-circle"></i> 
                          <?php endif; ?>   
                        </td>
                        <td>
                          <?php 
                          
                           $c_id= $value->id;
                           $query= DB::select(DB::raw(
                            "SELECT id, SUM(perday_sale) ts, SUM(duration) as td FROM keyword WHERE campaign_id=$c_id "));
                           //$k_w= \admin\Keyword::where('campaign_id',$c_id)->count('');
                           foreach($query as $v){

                            $totalSaleNeed= $v->ts*$v->td;
                            if($totalSaleNeed>0){

                            $k_id= $v->id;
                            $complete= DB::table('progress')->where('keyword_id',$k_id)->count();
                              $progress= 100*$complete/$totalSaleNeed;             
                              $p= number_format((float)$progress,'2','.','')."%";
                              echo 
                              '
                              <div class="progress">
                                <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="'.$p.'" aria-valuemin="0" aria-valuemax="100" style="min-width: 2em;width: '.$p.'" data-toggle="tooltip" title="'.$p.'">
                                  '.$p.' 
                                </div>
                              </div>
                              ' ;               
                            }
                            else{
                              echo "No keyword";
                            }

                           }
                          ?>
                        </td>                        
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>No record found</td>
                      </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                
              </div>
            </div>
          </div>
        </div>
        <!--body end-->
<div id="asign" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Asign employee to campaign</h4>
      </div>
        <div class="modal-body">
          <form class="form-horizontal modal-form" id="loginForm" method="post" action="<?php echo e(route('asignEmployee')); ?>">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="campaign_id">
            <div class="form-group">
                <label>Select Employee</label>
                <select class="form-control" name="employee_id" required>
                  <option select="">Select</option>
                  <?php $__empty_1 = true; $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>-<?php echo e($value->email); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <option>No employee found</option> 
                  <?php endif; ?>   
                </select>
            </div>
            <div class="form-group">
                  <button type="submit" class="btn btn-primary">Asign Employee</button>
            </div>
               
        </form>
      </div>

    </div>

  </div>
</div>
    </div><!--right col end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document.body).on('click','.asign',function(){
      
      var id= $(this).attr('id');
      $("[name='campaign_id']").val(id);
  })  

  $(document.body).on('click','.pending',function(){
      
      var id= $(this).attr('id');
      if(confirm('Do you want to update payment status?')){
          $.ajax({
            url : "<?php echo url('/home/update-payment-status')?>"+"/"+id,
            type: "GET",
            dataType: "HTML",
            success: function(data)
            {
              
              location.reload();
            },
            error: function (jqXHR, textStatus, errorThrown)
            {
                console.log('update failed');
            }
        });        
      }

  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>