<?php

namespace admin;

use Illuminate\Database\Eloquent\Model;

class Progress extends Model
{
    //table name
    public $table= "progress";
    protected $guarded= [];
}
