<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">

    <div class="row">
        <!--flass message-->
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
              <a class='close' data-dismiss='alert'>×</a>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>        
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
              <a class='close' data-dismiss='alert'>×</a>
                <h4><?php echo Session::get('success'); ?></h4>
            </div>
        <?php endif; ?>        

        <?php if(Session::has('fail')): ?>
            <div class="alert alert-danger">
                <h4><?php echo Session::get('fail'); ?></h4>
            </div>
        <?php endif; ?>
        
        </div>     
        <!--end flass message-->
        <div class="clearfix"></div>
        <!--body-->
        <div class="row">
          <div class="panel-default panel">
            <div class="panel-heading">
              <strong>All campaigns</strong>
            </div>

            <div class="panel-body">
              <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                        <th>Sl No:</th>
                        <th>A SIN</th>
                        <th>Product Link</th>
                        <th>Full Price</th>
                        <th>View Detail</th>
                        <th>Asign Employee</th>
                    </tr>
                    </thead>
                    <tbody>
                      <?php 
                        $i=1;
                      ?>

                    <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                      <tr>
                        <td><?php echo e($i++); ?></td>
                        <td><?php echo e($value->asin); ?></td>
                        <td><?php echo e($value->product_link); ?></td>
                        <td><?php echo e($value->full_price); ?></td>
                        <td><a href="<?php echo e(url('campaign-detail/')); ?>/<?php echo e($value->id); ?>" class="btn-primary btn btn-sm">View Detail</a></td>
                        <td>
                          <?php if($value->employee_id==0): ?>
                          <button data-toggle="modal"data-target="#asign" id="<?php echo e($value->id); ?>" class="btn-sm btn btn-info">Asign</button>
                          <?php else: ?>
                          <a href=""><?php echo e($value->name); ?></a>
                          <?php endif; ?>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                      <tr>
                        <td>No record found</td>
                      </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($campaigns->links()); ?>

              </div>
            </div>
          </div>
        </div>
        <!--body end-->
<div id="asign" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Asign employee to campaign</h4>
      </div>
        <div class="modal-body">
          <form class="form-horizontal modal-form" id="loginForm" method="post" action="">
            <input type="hidden" name="campaign_id">
            <div class="form-group">
                <label>Select Employee</label>
                <select class="form-control" name="employee_id" required>
                  <option select="">Select</option>
                  <?php $__empty_1 = true; $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <option select="<?php echo e($value->id); ?>"><?php echo e($value->name); ?>-<?php echo e($value->email); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <option>No employee found</option> 
                  <?php endif; ?>   
                </select>
            </div>
            <div class="form-group">
                  <button type="submit" class="btn btn-primary">Asign Employee</button>
            </div>
               
        </form>
      </div>

    </div>

  </div>
</div>
    </div><!--right col end -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  $(document.body).on('click','.asign',function(){
      var id= $(this).attr(id);
      alert(id);
  })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>