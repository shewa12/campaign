@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <center>Welcome to worklog</center>
    </div>
</div>
@endsection
