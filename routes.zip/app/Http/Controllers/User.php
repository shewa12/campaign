<?php

namespace admin\Http\Controllers;

use Illuminate\Http\Request;

class User extends Controller
{
    //
}
